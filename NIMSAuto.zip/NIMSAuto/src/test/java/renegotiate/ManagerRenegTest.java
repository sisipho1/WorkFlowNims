package renegotiate;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;
import pages.ManagerRenegotiate;
import util.ReadDataFromExcel;
import util.renegExcel;

public class ManagerRenegTest extends renegExcel{
	@Test(dataProvider="reneg",priority=6)
	public void renegotiateLeave(String name, String Remarks) {
		/*launch();
		LoginPage in=new LoginPage();
		in.login();*/
		ManagerRenegotiate reg=new ManagerRenegotiate();
		reg.leaveRenegotiate(name,Remarks);
		
	}
	
	
}
