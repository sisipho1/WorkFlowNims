package login;

import org.testng.annotations.Test;

import pages.LoginPage;
import util.ReadDataFromExcel2;

public class LoginTest2 extends ReadDataFromExcel2{
	
	@Test(dataProvider="Login2",priority=4)
	public void logIn(String username) {
		//launch();
		LoginPage in=new LoginPage();
		in.login(username);
		
	}

}
