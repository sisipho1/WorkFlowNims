package login;

import org.testng.annotations.Test;

import pages.LoginPage;
import util.ReadDataFromExcel3;

public class LoginTest3 extends ReadDataFromExcel3{
	
	@Test(dataProvider="Login3",priority=6)
	public void logIn(String username) {
		//launch();
		LoginPage in=new LoginPage();
		in.login(username);
	
	}
}
