package login;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;
import util.ReadDataFromExcel;

public class LoginTest extends ReadDataFromExcel{
	
	
	@Test(dataProvider="Login1",priority=1)
	public void logIn(String username) {
		LoginPage in=new LoginPage();
		in.login(username);
		
	}

}
