package home;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.HomePage;
import pages.LoginPage;

public class HomePageTest extends HomePage{
	
	@Test(priority=2)
	public void goToRequest() {
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//launch();
		//LoginPage in=new LoginPage();
		//in.login();
		HomePage home=new HomePage();
		home.homeToRequest();
	

		
	}
}
