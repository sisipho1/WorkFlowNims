package managerApprovals;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;
import pages.ManagerLeaveStatusApprovals;
import util.ReadDataFromExcel;
import util.managerExcel;

public class ManagerApprovalTest extends managerExcel{
	@Test(dataProvider="manager",priority=5)
	public void approveLeave(String name) {
		/*launch();
		LoginPage in=new LoginPage();
		in.login();*/
		ManagerLeaveStatusApprovals approve=new ManagerLeaveStatusApprovals();
		approve.managerLeaveApproval(name);
			
	}
	
}
