package reject;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;
import pages.ManagerReject;
import util.ReadDataFromExcel;
import util.rejectExcel;

public class ManagerRejectTest extends rejectExcel{
	@Test(dataProvider="reject",priority=5)
	public void rejectLeave(String name, String Remarks) {
		/*launch();
		LoginPage in=new LoginPage();
		in.login();*/
		ManagerReject reject=new ManagerReject();
		reject.leaveReject(name, Remarks);
		
	}
	
}
