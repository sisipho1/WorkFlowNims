package hrConfirmation;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.HRLeaveConfirmation;
import pages.LoginPage;
import util.ReadDataFromExcel;
import util.hrExcel;

public class HRConfirmationTest extends hrExcel{
	@Test(dataProvider="hr",priority=7)
	public void confirmLeave(String first_Name, String last_Name) {
		/*launch();
		LoginPage in=new LoginPage();
		in.login();*/
		HRLeaveConfirmation hr=new HRLeaveConfirmation();
		 hr.hrLeaveConfirm(first_Name,last_Name);
		
		
		
	}
	

}
