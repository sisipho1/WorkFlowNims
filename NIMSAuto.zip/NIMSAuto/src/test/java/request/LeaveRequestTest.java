package request;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.HomePage;
import pages.LeaveRequestPage;
import pages.LoginPage;
import util.LeaveExcel;
import util.ReadDataFromExcel;

public class LeaveRequestTest extends LeaveExcel{
	@Test(dataProvider="leave",priority=3)
	public void requestLeave(String purpose, String address, String email, String phoneNo) {
		/*launch();
		LoginPage in=new LoginPage();
		in.login();*/
		//HomePage home=new HomePage();
		//home.homeToRequest();
		LeaveRequestPage req=new LeaveRequestPage();
		req.leaveRequest(purpose,address,email,phoneNo);
		
	}
	

}
