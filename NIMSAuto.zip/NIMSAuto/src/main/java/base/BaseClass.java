package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import util.ReadDataFromExcel;





public class BaseClass {
	
	public static WebDriver driver;
	public static Properties prop;
	public static File file;
	public static FileInputStream fis;
	
	public static void readPropertiesFile() throws IOException {
		//to read the file that we have created in "Project Properties"
		file = new File(System.getProperty("user.dir") + "\\src\\main\\java\\config\\config.properties"); // to get the file path
		
		System.out.println(file);
		fis = new FileInputStream (file);
		prop = new Properties();
		prop.load(fis); //load file

		}
		
	
	
	
	public static void launch() {

		/*String browserType = prop.getProperty("browser");

		if (browserType.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\S987215\\Downloads\\chromedriver_win32\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("disable-infobars");
			driver = new ChromeDriver(options);

		} else if (browserType.equalsIgnoreCase("firefox")) {
			// TODO write code for Firefox

		}*/
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\S987215\\Downloads\\Chrome\\chromedriver_win32\\chromedriver.exe");
		//System.setProperty("webdriver.gecko.driver","C:\\Program Files (x86)\\geckodriver-v0.24.0-win64\\geckodriver.exe");
		ChromeOptions options = new ChromeOptions();
		System.out.println(options);
		options.addArguments("disable-infobars");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//driver = new FirefoxDriver();
		driver.get("https://nimsuat.nihilent.com/hrms/");
		
	}
		
		public static void click(By element) {
			try {
			driver.findElement(element).click();
			} catch(Exception e) {
			e.printStackTrace();
			System.out.println("Not able to click on element");
			}
			}
		
		public static void sendkeys(By element, String text) {
			try {
			driver.findElement(element).sendKeys(text);
			System.out.println("Keys sent successfully");
			} catch(Exception e) {
			e.printStackTrace();
			System.out.println("Not able to enter text");

			}
			}
		
		public static void dropDownText(By leaveType, String value) {
			try {
				Select org = new Select( driver.findElement(leaveType));
				//Select organization = new Select(org);
				org.selectByVisibleText(value);
				System.out.println("Item selected from dropdown");
			}
			catch(Exception e) {
				e.printStackTrace();
				System.out.println("Unable to select from dropdown");
			}
			
			
		}
		
		public static void dropDownIndex(By leaveType, int index) {
			try {
				Select org = new Select( driver.findElement(leaveType));
				//Select organization = new Select(org);
				org.selectByIndex(index);
				System.out.println("Item selected from dropdown");
			}
			catch(Exception e) {
				e.printStackTrace();
				System.out.println("Unable to select from dropdown");
			}
			
			
		}
		
		
	}
	


