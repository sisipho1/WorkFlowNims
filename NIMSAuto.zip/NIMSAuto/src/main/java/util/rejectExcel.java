package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import base.BaseClass;

public class rejectExcel extends BaseClass {
	WebDriver driver;
	XSSFWorkbook wb;
	@Test(dataProvider="reject")
	public Object[][] rejectConfirmData() throws IOException
	{
		File fs=new File("C:\\Users\\S987215\\Desktop\\ExcelSheet.xlsx");
		FileInputStream fis=new FileInputStream(fs);
		wb=new XSSFWorkbook(fis);
		XSSFSheet xs=wb.getSheet("Manager_Approval_Page");
		
		int rowcount =xs.getPhysicalNumberOfRows();
		int col = xs.getRow(0).getLastCellNum();
		System.out.println(rowcount);
		System.out.println(col);
		String[][] datas=new String[rowcount-1][col];

		
		for(int i=1;i<rowcount;i++) {
			for(int j=0;j<col;j++) {
				
				String cellvalue=xs.getRow(i).getCell(j).toString();
				datas[i-1][j]=cellvalue;
				System.out.println(cellvalue);
				
			}
		}
		
		return datas;
	}
	
}
