package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import base.BaseClass;

public class ReadDataFromExcel2 extends BaseClass{
	
	WebDriver driver;
	//String[][] datas=new String[1][1];
	
	XSSFWorkbook wb;
	
	@BeforeTest
	@DataProvider(name="Login2")
public Object[][] loginData() throws IOException
{
	File fs=new File("C:\\Users\\S987215\\Desktop\\ExcelSheet.xlsx");
	FileInputStream fis=new FileInputStream(fs);
	wb=new XSSFWorkbook(fis);
	XSSFSheet xs=wb.getSheet("Sheet1");
	
	int rowcount =xs.getPhysicalNumberOfRows();
	int col = xs.getRow(0).getLastCellNum();
	System.out.println(rowcount);
	System.out.println(col);
	String[][] datas=new String[rowcount-1][col];

	
	for(int i=1;i<rowcount;i++) {
		for(int j=0;j<col;j++) {
			
			String cellvalue=xs.getRow(i).getCell(j).getStringCellValue();
			datas[i-1][j]=cellvalue;
			System.out.println(cellvalue);
			
		}
	}
	
	return datas;
}
	
	
	

}
