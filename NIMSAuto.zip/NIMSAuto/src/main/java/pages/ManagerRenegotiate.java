package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import base.BaseClass;
import pageLocators.ManagerRenegLocators;

public class ManagerRenegotiate extends BaseClass{
	
	//public static final String NAME="Ankur";
	//public static final String REMARKS_TEXT="May we please talk about this leave";
	
	public void leaveRenegotiate(String name, String Remarks) {
		
driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		click(By.xpath(ManagerRenegLocators.myProfile));
		click(By.xpath(ManagerRenegLocators.myApprovals));
		click(By.xpath(ManagerRenegLocators.clickLeave));
		sendkeys(By.xpath(ManagerRenegLocators.clickSearch),name);
		click(By.xpath(ManagerRenegLocators.clickCheckBox));
		sendkeys(By.xpath(ManagerRenegLocators.remarksTextBox),Remarks);
		click(By.xpath(ManagerRenegLocators.renegotiateButton));
		
		Alert alert=driver.switchTo().alert();
		alert.accept();
		//driver.switchTo().defaultContent();
		click(By.xpath(ManagerRenegLocators.clickSignout));
		
		//login();
		
	}
	

}
