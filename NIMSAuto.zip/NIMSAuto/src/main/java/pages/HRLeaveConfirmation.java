package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import base.BaseClass;
import pageLocators.HRLeaveLocators;

public class HRLeaveConfirmation extends BaseClass{
	
	/*public static final String FIRST_NAME="Ankur";
	public static final String LAST_NAME="t";
	public static final String ASSOCIATE_ID="8210";
*/
	
public void hrLeaveConfirm(String first_Name, String last_Name) {
	
	click(By.xpath(HRLeaveLocators.HRClick));
	//driver.findElement(By.xpath("//nav[@id='main-nav']/ul/li[4]/a")).click();
	click(By.xpath(HRLeaveLocators.clickLeave));
	//driver.findElement(By.xpath("//a[text()='Leave']")).click();
	click(By.xpath(HRLeaveLocators.clickConfirmLeave));
	//driver.findElement(By.xpath("//a[@class='hyperlinkrclick'][text()=' Confirm Leave ']")).click();
	//sendkeys(By.xpath(HRLeaveLocators.associateId),assocId);
	//driver.findElement(By.xpath("//input[@id='associateByAssociateId']")).sendKeys("8210");
	sendkeys(By.xpath(HRLeaveLocators.firstName),first_Name);
	
	sendkeys(By.xpath(HRLeaveLocators.lastName),last_Name);
	
	click(By.xpath(HRLeaveLocators.clickSearch));
	//driver.findElement(By.xpath("//input[@id='btnPendingForHR']")).click();
	click(By.xpath(HRLeaveLocators.clickUserCheckBox));
	//driver.findElement(By.xpath("//tbody/tr[3]/td[2]/a")).click();
	click(By.xpath(HRLeaveLocators.clickProcess));
	//driver.findElement(By.xpath("//input[@id='btnProcess']")).click();
	
	Alert alert=driver.switchTo().alert();
	alert.accept();
	driver.switchTo().defaultContent();
	click(By.xpath(HRLeaveLocators.clickSignout));
	//driver.findElement(By.xpath(HRLeaveLocators.clickSignout)).click();
	
}

}
