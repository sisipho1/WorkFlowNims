package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import base.BaseClass;
import pageLocators.ManagerLeaveLocators;

public class ManagerLeaveStatusApprovals extends BaseClass{
	
	//public static final String NAME="Ankur";
	
	public void managerLeaveApproval(String name) {
	
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	click(By.xpath(ManagerLeaveLocators.myProfileClick));
	click(By.xpath(ManagerLeaveLocators.myApprovalsClick));
	click(By.xpath(ManagerLeaveLocators.clickLeave));
	sendkeys(By.xpath(ManagerLeaveLocators.clickSearchBox),name);
	click(By.xpath(ManagerLeaveLocators.clickCheckBox));
	click(By.xpath(ManagerLeaveLocators.clickApprove));
	
	Alert alert=driver.switchTo().alert();
	alert.accept();
	//driver.switchTo().defaultContent();
	click(By.xpath(ManagerLeaveLocators.clickSignout));
	//driver.findElement(By.xpath("//a[text()='Signout']")).click();
	
	}
	

}
