package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import base.BaseClass;
import pageLocators.ManagerRejectLocators;

public class ManagerReject extends BaseClass{
	
	//public static final String NAME="Ankur";
	//public static final String REMARKS_TEXT="May we please talk about this leave";
	
	public void leaveReject(String name, String Remarks) {
		
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	click(By.xpath(ManagerRejectLocators.myProfile));
	
	click(By.xpath(ManagerRejectLocators.myApprovals));

	click(By.xpath(ManagerRejectLocators.clickLeave));
	
	sendkeys(By.xpath(ManagerRejectLocators.clickSearchBox),name);
	
	click(By.xpath(ManagerRejectLocators.clickCheckBox));
	
	sendkeys(By.xpath(ManagerRejectLocators.remarks),Remarks);
	
	click(By.xpath(ManagerRejectLocators.rejectButton));
	
	
	Alert alert=driver.switchTo().alert();
	alert.accept();
	//driver.switchTo().defaultContent();
	click(By.xpath(ManagerRejectLocators.clickSignout));
	//driver.findElement(By.xpath("//a[text()='Signout']")).click();
	
	}
	

}
