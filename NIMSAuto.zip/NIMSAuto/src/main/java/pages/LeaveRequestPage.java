package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import base.BaseClass;
import pageLocators.LeaveRequestLocators;

public class LeaveRequestPage extends BaseClass{
	
	/*public static final String APPROVER_ID="Shashank Jadhao";
	public static final String PURPOSE="family responsibility";
	public static final String ADDRESS="PUNE";
	public static final String EMAIL="ankur.t@nihilent1.com";
	public static final String PHONE_NUMBER="076576587587";
	*/

	public void leaveRequest(String purpose, String address, String email, String phoneNo) {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);	
		dropDownIndex(By.xpath(LeaveRequestLocators.leaveType),1);
		//click(By.xpath(LeaveRequestLocators.clickCasual));
		//dropDownText(By.xpath(LeaveRequestLocators.approverId),approverId);
		Select approve=new Select(driver.findElement(By.xpath("//select[@id='associateByApproverId']")));
		approve.selectByValue("1409");
		
	//driver.findElement(By.xpath("//img[@class='ui-datepicker-trigger'][@title='From Date']")).click();
	//driver.findElement(By.xpath("//a[text()='24']")).click();
	click(By.xpath(LeaveRequestLocators.fromDateclick));
	click(By.xpath(LeaveRequestLocators.fromMonthSelect));
	click(By.xpath(LeaveRequestLocators.fromDate));
	
	click(By.xpath(LeaveRequestLocators.toDateClick));
	click(By.xpath(LeaveRequestLocators.toMonthSelect));
	click(By.xpath(LeaveRequestLocators.toDate));
	
	//driver.findElement(By.xpath("//a[text()='24']")).click();
	sendkeys(By.xpath(LeaveRequestLocators.purposeTextBox),purpose);
	sendkeys(By.xpath(LeaveRequestLocators.addressTextBox),address);
	sendkeys(By.xpath(LeaveRequestLocators.emailId),email);
	sendkeys(By.xpath(LeaveRequestLocators.phoneNumber),phoneNo);
	click(By.xpath(LeaveRequestLocators.submitRequest));
	click(By.xpath(LeaveRequestLocators.afterSubmit));
	click(By.xpath(LeaveRequestLocators.requestSignout));
	
	}
	
	
	

}
