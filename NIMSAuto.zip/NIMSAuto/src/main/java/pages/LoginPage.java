package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import base.BaseClass;
import pageLocators.LoginPageLocators;

public class LoginPage extends BaseClass{
	
	//public static final String USER_NAME=username;

	
public void login(String username) {
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendkeys(By.xpath(LoginPageLocators.username),username);
		//driver.findElement(By.xpath("//input[@id='j_username']")).sendKeys("ankur.t@nihilent1.com");
		dropDownIndex(By.xpath(LoginPageLocators.organization),1);
		//Select org=new Select(driver.findElement(By.xpath("//select[@name='companyIdOnSign']")));
		//org.selectByIndex(1);
		click(By.xpath(LoginPageLocators.submit));
		//driver.findElement(By.xpath("//input[@type='submit']")).click();
		
}



}
