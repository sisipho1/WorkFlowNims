package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import base.BaseClass;
import pageLocators.homePageLocators;

public class HomePage extends BaseClass{
	
	//public static final String NIHILENT_LIMITED="Nihilent Limited";
	
	public void homeToRequest() {
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);	
		click(By.xpath(homePageLocators.myProfile));
	click(By.xpath(homePageLocators.myRequest));
	click(By.xpath(homePageLocators.requestLeave));
	}
	
}