package pageLocators;

public class ManagerLeaveLocators {
	
	public static String myProfileClick="//a[text()='My Profile']";
	public static String myApprovalsClick="//a[text()='My Approvals']";
	public static String clickLeave="//a[text()='My Approvals']/following::a[text()=' Leave ']";
	public static String clickSearchBox="//input[@type='search']";
	public static String clickCheckBox="//input[@id='selectedForms']";
	//public static String clickCheckBox="//div[@id='example_wrapper']/descendant::tr[8]/td/input";
	public static String clickApprove="//input[@id='btnBulkApprove']";
	public static String clickSignout="//a[text()='Signout']";
}
