package pageLocators;

public class LoginPageLocators {
	
	public static String username= "//input[@id='j_username']";
	public static String organization= "//select[@name='companyIdOnSign']";
	public static String submit="//input[@type='submit']";
	
	
	
	
}
