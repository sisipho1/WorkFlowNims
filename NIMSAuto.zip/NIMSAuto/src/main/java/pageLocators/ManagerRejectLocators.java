package pageLocators;

public class ManagerRejectLocators {
	
	public static String myProfile="//a[@class='drop has-submenu'][text()='My Profile']";
	public static String myApprovals="//a[@class='hyperlinkrclick has-submenu'][text()='My Approvals']";
	public static String clickLeave="//a[@class='hyperlinkrclick'][text()=' Leave ']";
	public static String clickSearchBox="//input[@type='search']";
	public static String clickCheckBox="//input[@id='selectedForms']";
	//public static String clickCheckBox="//div[@id='example_wrapper']/descendant::tr[8]/td/input";
	public static String remarks="//textarea[@id='approverComment_602048']";
	public static String rejectButton="//input[@id='btnBulkReject']";
	public static String clickSignout="//a[@class='linkblack'][text()='Signout']";
	
	
}
