package pageLocators;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

public class HRLeaveLocators {
	
	public static String HRClick="//a[@class='drop has-submenu'][text()='HR']";
	public static String clickLeave="//a[@class='hyperlinkrclick has-submenu'][text()='Leave']";
	public static String clickConfirmLeave="//a[@class='hyperlinkrclick'][text()=' Confirm Leave ']";
	public static String associateId="//input[@id='associateByAssociateId']";
	public static String firstName="//input[@id='firstName']";
	public static String lastName="//input[@id='lastName']";
	public static String clickSearch="//input[@id='btnPendingForHR']";
	public static String clickUserCheckBox="//input[@type='checkbox'][@value='602047']";
	public static String clickProcess="//input[@id='btnProcess']";
	public static String clickSignout="//a[@class='linkblack'][text()='Signout']";
	
	
}
