package pageLocators;

public class LeaveRequestLocators {
	public static String leaveType="//select[@id='leaveType']";
	//public static String clickCasual="//select[@id='leaveType']/child::option[text()='Casual Leave']";
	public static String approverId="//select[@id='associateByApproverId']";
	public static String fromDateclick="//img[@class='ui-datepicker-trigger'][@title='From Date']";
	public static String fromMonthSelect="//select[@class='ui-datepicker-month']/child::option[@value='4']";
	public static String fromDate="//a[@class='ui-state-default'][text()='17']";
	public static String toDateClick="//img[@class='ui-datepicker-trigger'][@title='To Date']";
	public static String toMonthSelect="//select[@class='ui-datepicker-month']/child::option[@value='4']";
	public static String toDate="//a[@class='ui-state-default'][text()='17']";
	public static String purposeTextBox="//textarea[@id='purpose']";
	public static String addressTextBox="//textarea[@id='address']";
	public static String emailId="//input[@id='email']";
	public static String phoneNumber="//input[@id='phoneNo']";
	public static String submitRequest="//input[@id='btnSubmit']";
	public static String afterSubmit="//img[@src='images/btn_pdf.gif'][@border='0']";
	public static String requestSignout="//a[@class='linkblack'][text()='Signout']";
	
	

}
