package pageLocators;

public class ManagerRenegLocators {
	
	public static String myProfile="//a[@class='drop has-submenu'][text()='My Profile']";
	public static String myApprovals="//a[@class='hyperlinkrclick has-submenu'][text()='My Approvals']";
	public static String clickLeave="//a[@class='hyperlinkrclick'][text()=' Leave ']";
	public static String clickSearch="//input[@type='search']";
	public static String clickCheckBox="//input[@id='selectedForms']";
	public static String remarksTextBox="//textarea[@id='approverComment_602049']";
	public static String renegotiateButton="//input[@id='btnBulkReNegotiateByApprover']";
	public static String clickSignout="//a[@class='linkblack'][text()='Signout']";
	
}
