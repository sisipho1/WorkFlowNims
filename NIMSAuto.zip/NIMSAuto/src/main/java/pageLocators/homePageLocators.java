package pageLocators;

public class homePageLocators {
	public static String myProfile="//a[text()='My Profile']";
	public static String myRequest="//a[@class='hyperlinkrclick has-submenu'][text()='My Requests']";
	public static String requestLeave="//a[text()=' Request Leave ']";
	
	
	

}
