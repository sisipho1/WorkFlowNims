package masbsFlow;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import com.test.Nims.Base.baseClass;
import Locators.loginLocators;
import Locators.pendingRequestsLocators;
import Locators.reportProblemLocators;

public class pendingRequests extends baseClass {

	public static void pendingMethod(String comment, String ref) throws InterruptedException {
	   
		/*
		 * launch();
		 * 
		 * //Login sendKeys(By.xpath(loginLocators.emailId), emailId1);
		 * //sendKeys(By.xpath(loginLocators.passwrd),passwrd); Select dropdwn = new
		 * Select (driver.findElement(By.xpath(loginLocators.organization)));
		 * dropdwn.selectByVisibleText("Nihilent Limited");
		 * click(By.xpath(loginLocators.button));
		 */
	
	String expectedTitle = "NIMS";
	String actualTitle = driver.getTitle(); 
	//wb.close();
		if (expectedTitle==actualTitle) {
			System.out.println("User is able to sign in");
		}
		else {
			System.out.println("Invalid page");
		}
		
	
	// go to Report Problem
	
	Thread.sleep(1000);
	click(By.xpath(pendingRequestsLocators.helpDesk2));
	Thread.sleep(1000);
	click(By.xpath(pendingRequestsLocators.subMenu));
	Thread.sleep(1000);
	click(By.xpath(pendingRequestsLocators.pending));
	Thread.sleep(1000);
	click(By.xpath(pendingRequestsLocators.search));
	Thread.sleep(1000);
	sendKeys(By.xpath(pendingRequestsLocators.search), ref);
	click(By.xpath(pendingRequestsLocators.refClick));
	Thread.sleep(1000);
	sendKeys(By.xpath(pendingRequestsLocators.myComment), comment);
	//click(By.xpath(pendingRequestsLocators.myComment));
	//Thread.sleep(1000);
	click(By.xpath(pendingRequestsLocators.status));
	Thread.sleep(1000);
	Select dropdown1 = new Select (driver.findElement(By.xpath(pendingRequestsLocators.status)));
	 dropdown1.selectByVisibleText("WIP");
	 Thread.sleep(1000);
	//click(By.xpath(pendingRequestsLocators.submitBtn));
	//Thread.sleep(1000);
	click(By.xpath(pendingRequestsLocators.Signout));
	Thread.sleep(1000);
	
	
	
	}
}
