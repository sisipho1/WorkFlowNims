package masbsFlow;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.test.Nims.Base.baseClass;

import Locators.loginLocators;

public class loginSuresh extends baseClass {

	public static void firstLogin () {
		
	    sendKeys(By.xpath(loginLocators.emailId), prop.getProperty("username"));
        sendKeys(By.xpath(loginLocators.organization),prop.getProperty("company"));
         //Select dropdwn = new Select (driver.findElement(By.xpath(loginLocators.organization)));
         //dropdwn.selectByVisibleText("Nihilent Limited");
          click(By.xpath(loginLocators.button));
	
  }
}