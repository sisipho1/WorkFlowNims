package masbsFlow;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.test.Nims.Base.baseClass;

import Locators.loginLocators;

public class loginShraddha extends baseClass {

public static void loginShraddha1() {
	
	sendKeys(By.xpath(loginLocators.emailId), prop.getProperty("username2"));
    sendKeys(By.xpath(loginLocators.organization),prop.getProperty("company"));
      //sendKeys(By.xpath(loginLocators.passwrd),passwrd);
      //Select dropdwn = new Select (driver.findElement(By.xpath(loginLocators.organization)));
      // dropdwn.selectByVisibleText("Nihilent Limited");
        click(By.xpath(loginLocators.button));
}

}
