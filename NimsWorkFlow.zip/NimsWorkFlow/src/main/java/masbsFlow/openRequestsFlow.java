package masbsFlow;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.test.Nims.Base.baseClass;

import Locators.approvalLocators;
import Locators.loginLocators;
import Locators.openRequestLocators;

public class openRequestsFlow extends baseClass {
	
	 public static void niharika(String Remarks, String reference) throws InterruptedException {
		
		/*
		 * launch();
		 * 
		 * //Login sendKeys(By.xpath(loginLocators.emailId), email);
		 * //sendKeys(By.xpath(loginLocators.passwrd),passwrd); Select dropdwn = new
		 * Select (driver.findElement(By.xpath(loginLocators.organization)));
		 * dropdwn.selectByVisibleText("Nihilent Limited");
		 * click(By.xpath(loginLocators.button));
		 */
	
	    String expectedTitle = "NIMS";
	    String actualTitle = driver.getTitle(); 
	    //wb.close();
		if (expectedTitle==actualTitle) {
			System.out.println("User is able to sign in");
		}
		else {
			System.out.println("Invalid page");
		}
		
	
	
	// go to Open requests
	
	Thread.sleep(1000);
	click(By.xpath(openRequestLocators.menuHelpDesk));
	Thread.sleep(1000);
	click(By.xpath(openRequestLocators.subHelpDesk));
	Thread.sleep(1000);
	click(By.xpath(openRequestLocators.openReq));
	Thread.sleep(1000);
	sendKeys(By.xpath(openRequestLocators.fieldSearch), reference);;
	Thread.sleep(1000);
	click(By.xpath(openRequestLocators.searchField));
	Thread.sleep(1000);

	Select dropdwn5 = new Select (driver.findElement(By.xpath(openRequestLocators.associate)));
	 dropdwn5.selectByVisibleText("Niharika K Nagar");
	Thread.sleep(1000);
	//click(By.xpath(openRequestLocators.problemCategory));
	//Thread.sleep(1000);
	Select dropdwn6 = new Select (driver.findElement(By.xpath(openRequestLocators.associate)));
	 dropdwn6.selectByVisibleText("Time and Attendance");
	sendKeys(By.xpath(openRequestLocators.commentField), Remarks);;
	Thread.sleep(1000);
	//click(By.xpath(openRequestLocators.reAssignBtn));
	Thread.sleep(1000);
	
	click(By.xpath(openRequestLocators.Signout));

		
	}
}

