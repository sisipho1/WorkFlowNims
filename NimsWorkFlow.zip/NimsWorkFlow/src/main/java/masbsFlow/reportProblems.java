package masbsFlow;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.SendKeysAction;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import com.test.Nims.Base.baseClass;
import Locators.loginLocators;
import Locators.reportProblemLocators;
import NIMS.util.LoginExcelData;
import NIMS.util.reportProblemExcelData;


public class reportProblems extends baseClass{

@Test(dataProviderClass = reportProblemExcelData.class, dataProvider="report")
	public static void reportPage(String description, String fromDate, String toDate, String group, String category, String ProblemTitle, String approver) throws InterruptedException {
		/*
		 * launch();
		 * 
		 * //Login sendKeys(By.xpath(loginLocators.emailId), username);
		 * //sendKeys(By.xpath(loginLocators.passwrd),passwrd); Select dropdwn = new
		 * Select (driver.findElement(By.xpath(loginLocators.organization)));
		 * dropdwn.selectByVisibleText("Nihilent Limited");
		 * click(By.xpath(loginLocators.button));
		 */
	
	String expectedTitle = "NIMS";
	String actualTitle = driver.getTitle(); 
	//wb.close();
		if (expectedTitle==actualTitle) {
			System.out.println("User is able to sign in");
		}
		else {
			System.out.println("Invalid page");
		}
		
	
	
	// go to Report Problem
	
	Thread.sleep(1000);
	click(By.xpath(reportProblemLocators.myProfile1));
	Thread.sleep(1000);
	click(By.xpath(reportProblemLocators.myRequests));
	Thread.sleep(1000);
	click(By.xpath(reportProblemLocators.reportProb));
	Thread.sleep(1000);
	
	dropdown(By.xpath(reportProblemLocators.groupId),group);
	
	Thread.sleep(1000);
		/*
		 * Select dropdwn1 = new Select
		 * (driver.findElement(By.xpath(reportProblemLocators.category)));
		 * dropdwn1.selectByVisibleText("Time and Attendance");
		 */
	
		dropdown(By.xpath(reportProblemLocators.category),category);
		 dropdown(By.xpath(reportProblemLocators.problemTitle),ProblemTitle);
		 
		 driver.switchTo().alert().dismiss();
		 
		 click(By.xpath(reportProblemLocators.fromDate)); 
		 Thread.sleep(1000);
		 click(By.xpath(reportProblemLocators.exactFromDate)); 
		 Thread.sleep(1000);
		 
		 click(By.xpath(reportProblemLocators.dateFrom)); 
		 Thread.sleep(1000);
		 
		 List<WebElement>dates = driver.findElements(By.xpath(reportProblemLocators.dateFrom)); 
		 int total =dates.size();
		    for(int i = 0; i<total; i++) { 
			      String date=dates.get(i).getText();
		       if (date.equalsIgnoreCase("06/12/2019")) {
			      dates.get(i).click(); break;
			  } 
		  }
		 sendKeys(By.xpath(reportProblemLocators.fromDate),fromDate);
		 Thread.sleep(1000);
		 
		 click(By.xpath(reportProblemLocators.toDate)); Thread.sleep(1000);
		 click(By.xpath(reportProblemLocators.exactToDate)); Thread.sleep(1000);
		 click(By.xpath(reportProblemLocators.datePicker)); List<WebElement> date1 =
		 driver.findElements(By.xpath(reportProblemLocators.datePicker)); 
		 
		 int calendar = date1.size(); 
		     for (int x = 0; x < calendar; x++) { 
			       String cal=date1.get(x).getText(); 
		        if (cal.equalsIgnoreCase("06/12/2019")) {
		                date1.get(x).click(); 
		              break;
		              } 
		        }
		 sendKeys(By.xpath(reportProblemLocators.toDate),toDate); Thread.sleep(1000);
		 
		/*
		 * Select dropdwn3 = new Select
		 * (driver.findElement(By.xpath(reportProblemLocators.groupId)));
		 * dropdwn3.selectByVisibleText("Time and Attendance");
		 */
		// click(By.xpath(reportProblemLocators.category)); 
		 Thread.sleep(1000); 
		 //Select dropdwn4 = new Select (driver.findElement(By.xpath(reportProblemLocators.projectManager)));
		 //dropdwn4.selectByVisibleText("Shashank Jadhao");
		 dropdown(By.xpath(reportProblemLocators.projectManager),approver);
		 sendKeys(By.xpath(reportProblemLocators.comment),description);
		Thread.sleep(1000); click(By.xpath(reportProblemLocators.submitBtn));
		click(By.xpath(reportProblemLocators.Signout));
		
		
	}
}
