package com.test.Nims.Base;
	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.IOException;
	import java.net.MalformedURLException;
	import java.net.URL;
	import java.util.List;
	import java.util.Properties;
	import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.chrome.ChromeOptions;
	import org.openqa.selenium.remote.CapabilityType;
	import org.openqa.selenium.remote.DesiredCapabilities;
	import org.openqa.selenium.support.ui.Select;
	import org.testng.annotations.BeforeSuite;

import NIMS.util.LoginExcelData;

	public class baseClass {

		public static Properties prop;
		public static File file1;
		public static FileInputStream fis1;
		public static WebDriver driver;


		public baseClass () {

			prop = new Properties();
			try {
				FileInputStream fileInput = new FileInputStream(System.getProperty("user.dir")
						+ "//src//main//java//NIMS//" + "//configur//config.properties");
				prop.load(fileInput);

			} catch (FileNotFoundException e) {
				e.printStackTrace();

			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	
		public static void launch() {

			String browserType = prop.getProperty("browser");

			if (browserType.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\G987324\\Downloads\\chromedriver_win32\\chromedriver.exe");
				ChromeOptions options = new ChromeOptions();
				options.addArguments("disable-infobars");
				driver = new ChromeDriver(options);

			} else if (browserType.equalsIgnoreCase("chrome")) {
				// TODO write code for Firefox

			}
			
			
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.get(prop.getProperty("url"));
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			System.out.println("Application Launched successfully");
			
			//WebDriverWait wait = new WebDriverWait (driver, 10);
			
		}
		
		
		public static void click(By element) {
			
			try {
				driver.findElement(element).click();
				System.out.println("Element got clicked successfully");
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Not able to click the element");
			}
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		}
		
		
		public static void sendKeys(By element, String text) {
			
			try {
				driver.findElement(element).sendKeys(text);
				System.out.println("Element got clicked successfully");
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Not able to enter text");
			}
			//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		}
		
		
		//dropdown
		
	
	  public static void dropdown(By locator, String key) {
	  
	  try { 
		  WebElement org= (WebElement)driver.findElement(locator);
	      Select organization = new Select(org);
	      organization.selectByVisibleText(key);
	      System.out.println("Item has been selected from the dropdown");
	  
	  } 
	  catch (Exception e) { // TODO Auto-generated catch block
	  e.printStackTrace();
	  System.out.println("Unable to select the value from Dropdown"); } }
	 
		
		public static void select(By ele, String value) {
			try {
				Select company = new Select(driver.findElement(ele));
				company.selectByVisibleText(value);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Text Not Selected");
			}
			
		}
		
	/*
	 * public static void selectIndex(By ele, int x) { Select group = new
	 * Select(driver.findElement(ele)); group.selectByIndex(1); }
	 */
		
		
	public static String getText(By locator) {
			String result="";
			
			try {
				result = driver.findElement(locator).getText();
				System.out.println("Text sent successfully: ");
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Not able to get the text");
			}
			return result;
	}
	
	public static String alertText (String message) {
		Alert alert = driver.switchTo().alert();
		message =  alert.getText();
		return message;
	}
	
		
	}
