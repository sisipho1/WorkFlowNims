package pages;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.test.Nims.Base.baseClass;
import NIMS.util.LoginExcelData;


public class LoginPage extends baseClass {
	

  public void Login (String emailId) throws IOException{
		  launch();
	      driver.findElement(By.id("j_username")).sendKeys(emailId);
		   Select dropdwn = new Select (driver.findElement(By.name("companyIdOnSign")));
		   dropdwn.selectByVisibleText("Nihilent Limited");
		  driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		  driver.findElement(By.id("loginBtn")).click();
		 
		// wb.close();
			// verify if page coming is what I was expected or not
			String expectedTitle = "NIMS";
			String actualTitle = driver.getTitle(); 
			
			
				if (expectedTitle==actualTitle) {
					System.out.println("User is able to sign in");
				}
				else {
					System.out.println("Invalid page");
				}
		 
	}
	

}