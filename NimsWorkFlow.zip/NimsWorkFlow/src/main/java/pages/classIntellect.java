package pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.test.Nims.Base.baseClass;

public class classIntellect extends baseClass {
	
@Test(dataProvider ="login_Data")
public void intellect (String username) throws IOException {
		
				
		  driver.findElement(By.id("j_username")).sendKeys(username);
		 
		  Select dropdwn = new Select (driver.findElement(By.name("companyIdOnSign")));
		  dropdwn.selectByVisibleText("Intellect");
		  driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		  driver.findElement(By.id("loginBtn")).click();
		
		// verify if page coming is what I was expected or not
		String expectedTitle = "NIMS";
		String actualTitle = driver.getTitle(); 
		//wb.close();
			if (expectedTitle==actualTitle) {
				System.out.println("User is able to sign in");
			}
			else {
				System.out.println("Invalid page");
			}
  }	

}
