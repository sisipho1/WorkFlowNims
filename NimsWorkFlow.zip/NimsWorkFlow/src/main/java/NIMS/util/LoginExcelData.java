package NIMS.util;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import com.test.Nims.Base.baseClass;

public class LoginExcelData extends baseClass{
	 protected WebDriver driver ;
	  protected XSSFWorkbook wb;
	
@BeforeTest
@DataProvider(name="ReadExcelData")

public Object[][]  ReadLoginExceldata() throws IOException {
		File fs = new File("C:\\Users\\G987324\\Desktop\\Book12.xlsx");
		FileInputStream fis = new FileInputStream(fs);
		wb = new XSSFWorkbook(fis);
		XSSFSheet xs = wb.getSheet("sheet1");
	//String[][] datas = new String [1][2]; //another way of calling your rows by using arrays
		
		int rowcount = xs.getPhysicalNumberOfRows(); // return exact number of rows
		int columncount = xs.getRow(0).getLastCellNum();
		System.out.println(rowcount);
		System.out.println(columncount);
		
		String[][] datas = new String [rowcount-1][columncount];
		
	 for(int i=1; i < rowcount; i++) {
		for(int m=0; m<columncount;m++) {
				String cellvalue = xs.getRow(i).getCell(m).toString(); // fetching data
				System.out.println(cellvalue);
				datas[i-1] [m] = cellvalue;
		    }
	}
		//wb.close();
		return datas;
		
	//another way of calling your rows and columns
		//int rowcount = xs.getPhysicalNumberOfRows();
		//int rowcount1 = xs.getFirstRowNum();
		//int rowcount2 = xs.getLastRowNum();
		
		
	}		
 }

