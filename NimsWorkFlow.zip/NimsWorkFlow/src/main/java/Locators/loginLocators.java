package Locators;

import com.test.Nims.Base.baseClass;

public class loginLocators extends baseClass {
	
	public static String emailId = "//input[@id='j_username']";
	public static String passwrd="//input[@id='j_password']";
	public static String organization="//select[@id='cookieValue']";
	public static String button="//input[@id='loginBtn']";
	
	
	
}
