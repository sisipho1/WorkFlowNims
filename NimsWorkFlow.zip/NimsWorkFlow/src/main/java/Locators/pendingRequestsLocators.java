package Locators;

import com.test.Nims.Base.baseClass;

public class pendingRequestsLocators extends baseClass{

	
	public static String helpDesk2 = "//a[contains(@class,'drop has-submenu') and text()='Help Desk']";
	public static String subMenu = "//a[@class='hyperlinkrclick has-submenu' and text()='Help Desk']";
    public static String pending="//ul[@id='sm-1562583221308898-26']/descendant:: a[text()=' Pending Requests ']";

    public static String search ="//div[@id=\'hdProblemRequestListTBL_filter\']/label/input";
    public static String refClick = "//table[@id=\'hdProblemRequestListTBL\']/tbody/tr[2]/td[1]/a";
    public static String myComment = "//textarea[@id='resolverComment']";
 
    public static String status ="//option[@value='4' and text()='WIP']";
 
    public static String submitBtn ="//input[@id='submitId']";
    public static String Signout = "//a[@class='linkblack'][text()='Signout']";

}
