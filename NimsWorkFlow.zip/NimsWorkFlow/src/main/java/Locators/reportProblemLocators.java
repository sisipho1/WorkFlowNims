package Locators;

import com.test.Nims.Base.baseClass;

public class reportProblemLocators extends baseClass{

	public static String myProfile1 ="//a[text()='My Profile']" ;
	public static String myRequests = "//a[text()='My Requests']";
	public static String reportProb = "//a[text()=' Report Problem ']";
	public static String groupId ="//select[@id='groupId']" ;
	public static String category ="//select[@id='categoryTitle']/descendant::option[@value='36']";
	public static String problemTitle = "//select[@id='problemTitle']";
	public static String fromDate = "//input[@id='fromDate']";
	public static String exactFromDate = "//a[contains(@class,'ui-state-default') and text()='12']";
	public static String dateFrom = "//div[@id='ui-datepicker-div']";
	public static String toDate = "//input[@id='toDate']";
	public static String exactToDate = "//a[contains(@class,'ui-state-default') and text()='19']";
	public static String datePicker = "//a[contains(@class,'ui-state-default') and text()='19']";
	public static String projectManager = "//select[@id='approverId']/descendant::option[@value='1409']";
	public static String comment = "//textarea[@id='description']";
	public static String submitBtn = "//input[@id='submitId']";
	public static String Signout = "//a[@class='linkblack'][text()='Signout']";
	
}

