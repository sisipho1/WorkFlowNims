package Locators;

import com.test.Nims.Base.baseClass;

public class approvalLocators extends baseClass {

	public static String myProfile ="//a[text()='My Profile']" ;
	public static String approvals = "//a[text()='My Approvals']";
	public static String approveProb = "//a[text()=' Approve Problem Request ']";
	public static String next ="//a[text()='Last']";
	public static String tableClick ="//table[@id=\"pendingList\"]/tbody/tr[9]/td[1]/a";
	public static String commentText = "//textarea[@id='comment']";
	public static String approveBtn = "//input[@value=' Approve']";
	
	public static String Signout = "//a[@class='linkblack'][text()='Signout']";
	
	
}
