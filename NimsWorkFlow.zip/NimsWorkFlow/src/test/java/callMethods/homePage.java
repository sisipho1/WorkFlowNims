package callMethods;
import org.testng.annotations.Test;
import org.testng.xml.LaunchSuite;
import com.test.Nims.Base.baseClass;

import NIMS.util.LoginExcelData;
import NIMS.util.approvalExcelData;

public class homePage extends baseClass{
	@Test( dataProviderClass=LoginExcelData.class, dataProvider ="ReadLoginExcelData")
  public void homePage1() {
	//launch();
 }
}
