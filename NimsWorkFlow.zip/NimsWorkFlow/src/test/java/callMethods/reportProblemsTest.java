package callMethods;

import java.io.IOException;

import org.testng.annotations.Test;

import com.test.Nims.Base.baseClass;

import NIMS.util.LoginExcelData;
import NIMS.util.reportProblemExcelData;
import masbsFlow.loginSuresh;
import masbsFlow.reportProblems;
import pages.classAnalytics;

public class reportProblemsTest extends baseClass {

	@Test( dataProviderClass=reportProblemExcelData.class, dataProvider ="ReadExcelData")
	   public void test (String description, String fromDate, String toDate, String group, String category, String ProblemTitle, String approver) throws IOException, InterruptedException{
		
		launch();
		//classAnalytics.analytics(username);
		loginSuresh.firstLogin();
		reportProblems.reportPage(description, fromDate, toDate, group ,category, ProblemTitle, approver);
		
	  }
}
