package callMethods;
import java.io.IOException;

import org.testng.annotations.Test;

import com.test.Nims.Base.baseClass;

import NIMS.util.LoginExcelData;
import NIMS.util.pendingRequestsExcelData;
import masbsFlow.loginNiharika;
import masbsFlow.pendingRequests;

public class pendingTest extends baseClass{
		
		@Test( dataProviderClass=pendingRequestsExcelData.class, dataProvider ="ReadPendingExcelData")
		   public void pendingTest1 (String comment, String ref) throws IOException, InterruptedException{
			
			launch();
			loginNiharika.niharikaLogin();
			pendingRequests.pendingMethod(comment, ref);
			
		  }
	}
