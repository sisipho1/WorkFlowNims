package callMethods;
import java.io.IOException;

import org.testng.annotations.Test;

import com.test.Nims.Base.baseClass;

import NIMS.util.LoginExcelData;
import NIMS.util.approvalExcelData;
import masbsFlow.approvals;
import masbsFlow.loginShraddha;

public class callApproval extends baseClass{

	@Test( dataProviderClass=approvalExcelData.class, dataProvider ="ReadApprovalExcelData")
	   public void callApprovalMethod (String comment) throws IOException, InterruptedException{
		
		launch();
		loginShraddha.loginShraddha1();
		approvals.approvalPage(comment);
		
	  }
}
