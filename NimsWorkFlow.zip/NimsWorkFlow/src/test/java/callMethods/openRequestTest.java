package callMethods;

import java.io.IOException;

import org.testng.annotations.Test;
import org.testng.xml.LaunchSuite;

import com.test.Nims.Base.baseClass;

import NIMS.util.LoginExcelData;
import NIMS.util.openRequestsExcelData;
import masbsFlow.loginNiharika;
import masbsFlow.openRequestsFlow;

public class openRequestTest extends baseClass {

	@Test( dataProviderClass=openRequestsExcelData.class, dataProvider ="ReadOpenExcelData")
	   public void openRequestMethod (String Remarks, String ref) throws IOException, InterruptedException{
		
		launch();
		
		loginNiharika.niharikaLogin();
		openRequestsFlow.niharika(Remarks,ref);
		
	  }

	
}
