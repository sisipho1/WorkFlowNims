package loginExtension;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.test.Nims.Base.baseClass;

import NIMS.util.LoginExcelData;
import pages.LoginPage;
import pages.classNAI_Inc;

public class negativeNAInc extends classNAI_Inc {
	private WebDriver wb;
  
@Test( dataProvider ="approval")
   public void test (String username) throws IOException {
	
	launch();
	classNAI_Inc Log = new classNAI_Inc();
	  Log.NAI_Inc(username);
	
	}

}
