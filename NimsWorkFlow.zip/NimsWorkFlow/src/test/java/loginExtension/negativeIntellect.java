package loginExtension;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import NIMS.util.LoginExcelData;
import pages.LoginPage;
import pages.classIntellect;

public class negativeIntellect extends classIntellect {
	private WebDriver wb;
	
	  
	@Test( dataProvider ="login_Data")
	   public void test2 (String username) throws IOException {
		
		launch();
		classIntellect Log = new classIntellect();
		  Log.intellect(username);
		
	  }
	}