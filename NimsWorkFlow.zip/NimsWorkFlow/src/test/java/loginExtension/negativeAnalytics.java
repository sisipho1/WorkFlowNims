package loginExtension;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import NIMS.util.LoginExcelData;
import pages.LoginPage;
import pages.classAnalytics;

public class negativeAnalytics extends classAnalytics {
	private WebDriver wb;
	  
	@Test( dataProvider ="login_Data")
	   public void test (String username) throws IOException {
		
		launch();
		classAnalytics  Log = new classAnalytics ();
		  Log.analytics(username);
		
	  }

}