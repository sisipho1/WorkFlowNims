package loginExtension;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import NIMS.util.LoginExcelData;
import pages.LoginPage;
import pages.classNihilent_Inc;

public class Negative_Nihilent_inc extends classNihilent_Inc{
	private WebDriver wb;
	
	@Test( dataProvider ="login_Data")
	   public void test (String username) throws IOException {
		
		launch();
		classNihilent_Inc Log = new classNihilent_Inc();
		  Log.nihilent_Inc(username);
		
	  }

	}
