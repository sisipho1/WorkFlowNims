package loginExtension;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.test.Nims.Base.baseClass;
import NIMS.util.LoginExcelData;
import masbsFlow.reportProblems;
import pages.LoginPage;

public class positiveLogin extends reportProblems {
  

@Test(dataProviderClass = LoginExcelData.class, dataProvider ="ReadExcelData")
public void test (String emailId, String comment) throws IOException, InterruptedException {
	
	//launch();
	reportProblems Log = new reportProblems();
	//Log.suresh(emailId, comment);
	
	
  }

}
